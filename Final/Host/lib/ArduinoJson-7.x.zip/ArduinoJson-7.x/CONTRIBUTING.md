# Contribution to ArduinoJson

First, thank you for taking the time to contribute to this project.

You can submit changes via GitHub Pull Requests.

Please:

1. Update the test suite for any change of behavior
2. Use clang-format in "file" mode to format the code
